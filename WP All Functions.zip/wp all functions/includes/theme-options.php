<?php
/**
 * Initialize the custom theme options.
 */
add_action( 'admin_init', 'custom_theme_options' );

/**
 * Build the custom settings & update OptionTree.
 */
function custom_theme_options() {
  /**
   * Get a copy of the saved settings array. 
   */
  $saved_settings = get_option( 'option_tree_settings', array() );
  
  /**
   * Custom settings array that will eventually be 
   * passes to the OptionTree Settings API Class.
   */
  $custom_settings = array( 
    'contextual_help' => array( 
      'sidebar'       => ''
    ),
    'sections'        => array( 
 
      array(
        'id'          => 'header',
        'title'       => 'Header'
      ),	  
      array(
        'id'          => 'footer',
        'title'       => 'Footer'
      )  
    ),


	  
    'settings'        => array( 
 
      array(
        'id'          => 'bodycolor',
        'label'       => 'Body Background',
        'desc'        => 'Choose a color that you would like to use for the body of the page.',
        'std'         => '',
        'type'        => 'background',
        'section'     => 'general',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),	   
 
 
       array(
        'id'          => 'logo',
        'label'       => 'Upload your Logo',
        'desc'        => 'Upload your own logo, or simply specify the URL directly. Delete or leave it empty to show text only.',
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'header',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),  
       array(
        'id'          => 'logotag',
        'label'       => 'Upload your Logo Tag',
        'desc'        => 'Upload your own logo, or simply specify the URL directly. Delete or leave it empty to show text only.',
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'header',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ), 	 
	  
      array(
        'id'          => 'logotagtext',
        'label'       => 'Logo Tag Text',      
        'std'         => '',
        'type'        => 'text',
        'section'     => 'header',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ), 		  
	
		array(
		'label'       => 'Service Title',
		'id'          => 'service_title',
		'type'        => 'text',
		'section'     => 'header',        
	),
		array(
		'label'       => 'Service Content',
		'id'          => 'service_content',
		'type'        => 'text',
		'section'     => 'header',        
	),

		array(
		'label'       => 'Service',
		'id'          => 'service_list',
		'type'        => 'list-item',
		'section'     => 'header',        
	),
	
		array(
		'label'       => 'About Title',
		'id'          => 'about_title',
		'type'        => 'text',
		'section'     => 'header',        
	),		
	
	array(
		'label'       => 'About Content',
		'id'          => 'about_content',
		'type'        => 'text',
		'section'     => 'header',        
	),
	array(
		'label'       => 'About Link with http',
		'id'          => 'about_link',
		'type'        => 'text',
		'section'     => 'header',        
	),
	
	array(
		'label'       => 'Our Product',
		'id'          => 'our_product',
		'type'        => 'text',
        'std'         => 'Our Product',		
		'section'     => 'header',        
	),

	array(
		'label'       => 'Our Product',
		'id'          => 'product_disc',
		'type'        => 'text',
        'std'         => 'Take a look to our awesome works',		
		'section'     => 'header',        
	),



      array(
        'id'          => 'copyright_text',
        'label'       => 'Custom Copyright Text',
        'desc'        => 'Enter your custom copyright message here',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'footer',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ) ,

      array(
        'id'          => 'copyright_text',
        'label'       => 'Custom Copyright Text',
        'desc'        => 'Enter your custom copyright message here',
        'std'         => '',
        'type'        => 'text',
        'section'     => 'footer',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ) 	  
	  
    )
  );
  
  /* allow settings to be filtered before saving */
  $custom_settings = apply_filters( 'option_tree_settings_args', $custom_settings );
  
  /* settings are not the same update the DB */
  if ( $saved_settings !== $custom_settings ) {
    update_option( 'option_tree_settings', $custom_settings ); 
  }
  
}