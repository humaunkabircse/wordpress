<?php
function royaltech_customize_register($wp_customize) 
{

$wp_customize->add_section('general_section' , array(
	'title' 		=> 'General Options',
	'priority' 		=> 20,
));

$wp_customize->add_section('home_page' , array(
	'title' 		=> 'Home Page Options',
	'priority' 		=> 21,
	
));$wp_customize->add_section('contact_page' , array(
	'title' 		=> 'Conatct Page Options',
	'priority' 		=> 22,
));





// Logo Image
$wp_customize->add_setting('logo_image', array(
	'default' 		=> get_bloginfo('template_directory') . '/images/logo.png',
	'transport' 	=> 'refresh',
));

$wp_customize->add_control(
	new WP_Customize_Image_Control($wp_customize, 'logo_image', array(
	'section'    	=> 'general_section',
	'label'      	=> 'Upload your logo (Better size 340px X 80px)',
	'type'       	=> 'upload',
	))
);




// Base Color
$wp_customize->add_setting('base_color', array(
	'default' 		=> '#323232',
	'transport' 	=> 'refresh',
));

$wp_customize->add_control(
	new WP_Customize_Color_Control($wp_customize, 'base_color', array(
	'section'    	=> 'general_section',
	'label'      	=> 'Base Color',
	'settings'       => 'base_color',
	))
);





// Copyright Text
$wp_customize->add_setting('copyright_text', array(
	'default' 		=> '',
	'transport' 	=> 'postMessage', // refresh
));

$wp_customize->add_control('copyright_text', array(
	'section'    	=> 'general_section',
	'label'      	=> 'Copyright Text (Keep blank for default text)',
	'type'       	=> 'text',
));



// Home Page Settings
$wp_customize->add_setting('home_page_grid_id', array(
	'default' 		=> '',
	'transport' 	=> 'postMessage', // refresh
));

$wp_customize->add_control('home_page_grid_id', array(
	'section'    	=> 'home_page',
	'label'      	=> 'Page ID (Like: 548,555,587,583,585)',
	'type'       	=> 'text',
));









// Contact Page Settings
$wp_customize->add_setting('google_map_iframe', array(
	'default' 		=> '',
	'transport' 	=> 'postMessage', // refresh
));

$wp_customize->add_control('google_map_iframe', array(
	'section'    	=> 'contact_page',
	'label'      	=> 'Copy-Past Google Map iframe here',
	'type'       	=> 'text',
));

$wp_customize->add_setting('contact7', array(
	'default' 		=> '',
	'transport' 	=> 'postMessage', // refresh
));

$wp_customize->add_control('contact7', array(
	'section'    	=> 'contact_page',
	'label'      	=> 'Copy-Past Contact7 Code here',
	'type'       	=> 'text',
));


}
add_action("customize_register","royaltech_customize_register");





function royaltech_customizer_live_preview(){
	wp_enqueue_script("royaltech-themecustomizer", get_template_directory_uri() . "/includes/customization-api.js", 
	array("jquery", "customize-preview"), '',  true);
}
add_action("customize_preview_init", "royaltech_customizer_live_preview");





function royaltech_inline_css(){
?>
	<style type="text/css">
	.header_top, .copy-right { background: <?php echo get_theme_mod('base_color'); ?>;}
	
	
	
	</style>
<?php
}
add_action("wp_footer", "royaltech_inline_css");












