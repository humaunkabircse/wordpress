<?php

// register custom post type to work with
add_action( 'init', 'royal_create_products_post_type' );
function royal_create_products_post_type() {
	// Products custom post type
	// set up labels
	$labels = array(
 		'name' => 'Products',
    	'singular_name' => 'Product',
    	'add_new' => 'Add New Product',
    	'add_new_item' => 'Add New Product',
    	'edit_item' => 'Edit Product',
    	'new_item' => 'New Product',
    	'all_items' => 'All Product',
    	'view_item' => 'View Product',
    	'search_items' => 'Search Product',
    	'not_found' =>  'No Product Found',
    	'not_found_in_trash' => 'No Product found in Trash', 
    	'parent_item_colon' => '',
    	'menu_name' => 'Product',
    );
	register_post_type( 'product', array(
		'labels' => $labels,
        'public' => true,
        'show_ui' => true,
        'publicly_queryable' => true,
        'query_var' => true,
        'hierarchical' => false,
        'rewrite' => false,
		'has_archive' => true,
		'menu_position' => 2,		
		'menu_icon' => 'dashicons-images-alt2',		
		'supports' => array( 'title', 'thumbnail','editor'),		
		'exclude_from_search' => false,
		'capability_type' => 'post',
		)
	);
}



// register two taxonomies to go with the post type
add_action( 'init', 'royaltech_create_taxonomies_product', 0 );
function royaltech_create_taxonomies_product() {

	// Product Cat taxonomy
	$labels = array(
		'name'              => _x( 'Product Cat', 'taxonomy general name' ),
		'singular_name'     => _x( 'Product Cat', 'taxonomy singular name' ),
		'search_items'      => __( 'Search Product Cat' ),
		'all_items'         => __( 'All Product Cat' ),
		'parent_item'       => __( 'Parent Product Cat' ),
		'parent_item_colon' => __( 'Parent Product Cat:' ),
		'edit_item'         => __( 'Edit Product Cat' ),
		'update_item'       => __( 'Update Product Cat' ),
		'add_new_item'      => __( 'Add New Product Cat' ),
		'new_item_name'     => __( 'New Product Cat' ),
		'menu_name'         => __( 'Product Cat' ),
	);
	register_taxonomy( 'product_cat', 'product', array(
		'hierarchical' => true,
		'labels' => $labels,
		'query_var' => true,
		'rewrite' => true,
		'show_admin_column' => true	
	) );
}



// Rename Title
function product_title_text_input ( $title ) {
	if ( get_post_type() == 'product' ) {
			$title = __( 'Products\'s name here' );
	}
	return $title;
	} 
add_filter( 'enter_title_here', 'product_title_text_input' );




/* Rename Featured Image */
add_action('do_meta_boxes', 'change_royal_product_image_box');
function change_royal_product_image_box()
{
    remove_meta_box( 'postimagediv', 'product', 'product' );
    add_meta_box('postimagediv', __('Set Product Image (Best Size: 800px X 524px)'), 'post_thumbnail_meta_box', 'product', 'side', 'high');
}


// custom Type Post============================================================



?>